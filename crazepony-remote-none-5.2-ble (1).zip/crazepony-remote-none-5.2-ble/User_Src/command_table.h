#ifndef __command_table_H
#define __command_table_H 			   



#define Syn_byte         0xa5
#define Unlock           0xa5
#define EnableAircraft   0xa5
#define ignore_parWrite  0



#endif

