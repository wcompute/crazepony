#ifndef _EXTERN_VARIABLE_H_
#define _EXTERN_VARIABLE_H_

 
//系统
extern uint8_t SYS_INIT_OK;					//系统初始化完成标志

#endif
                
        



