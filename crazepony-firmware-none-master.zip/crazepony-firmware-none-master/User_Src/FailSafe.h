#ifndef FAIL_SAFE_H
#define FAIL_SAFE_H

void AutoLand(void);

void FailSafe(void);

void FlightModeFSMSimple(void);

#endif

