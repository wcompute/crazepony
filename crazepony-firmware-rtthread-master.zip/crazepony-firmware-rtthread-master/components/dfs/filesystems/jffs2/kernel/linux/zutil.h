#ifndef __LINUX_ZUTIL_H__
#define __LINUX_ZUTIL_H__

#define PRESET_DICT 0x20 /* preset dictionary flag in zlib header */

#endif /* __LINUX_ZUTIL_H__ */
