#ifndef FAIL_SAFE_H
#define FAIL_SAFE_H


//
void AutoLand(void);

void FailSafeCrash(void);

void FailSafeLostRC(void);
 
void FailSafeLEDAlarm(void);

void FlightModeFSMSimple(void);
 
#endif

